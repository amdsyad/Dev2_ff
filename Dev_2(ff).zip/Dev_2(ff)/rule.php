<!DOCTYPE html>
<body style="background-color: powderblue;"></body>
<center><h2>Welcome To Rule Page!!! :xd</h2></center>
<center><img src="https://media.giphy.com/media/wUmp8UfCWdOA4BOZqT/giphy.gif"  width="300" height="300"></center>


<h3>Rule Here / hint :)</h3>
<h3>1. Exploit Owasp Top 10 ____ Injection</h3>
<h3>2. Bypass Something</h3>
<h3>3. Automate All Process in Python3  </h3>



