<?php
 session_start();
 include("connection.php");
 if(isset($_POST['submit'])){

    $uname  = $_POST['username'];
    $pass   = $_POST['password'];

    $sql = "SELECT * FROM user WHERE username = '$uname' AND password = '$pass' ";
    $result = mysqli_query($conn,$sql); 
   
    if (mysqli_num_rows($result)) {
        $_SESSION['auth'] = 1;
        header("Location: welcome.php");
    } else {
        echo "<script>alert('Wrong')</script>";
    }   
    
 }

?>


<!DOCTYPE html>

<html>
    <body style="background-color: powderblue;"></body>
    <center><h2>Welcome To login Page <>!!!</h2></center>
    <center><p>Rule Games are here <a href="rule.php">Rules</a></p></center>
    <center><img src="img/skull-image.jpg" alt="" width="300" height="300"></center>
</html>


<form method="POST" action="#">
    <center><label for="username">Username: </label></center>
    <center><input type="text" required="" name="username"></center><br>
    <center><label for="password">Password: </label></center>
    <center><input type="password" required="" name="password"></center>
    <center><input type="submit" name="submit"></center>
    <center><p>Register Here <a href="register.php">Register</a></p></center>
</form>
