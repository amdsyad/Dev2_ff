<?php

$servername = "localhost";
$username = "root";
$db = "web1";
$password = "";

$conn = new mysqli($servername, $username, $password, $db);

// Check Connection 

if($conn->connect_error){
    die("Connection Failed: " . $conn->connect_errno);
}
else
    // echo "Connection Success";

?>