<?php
$uploaddir  = 'img/';
$uploadfile =  $uploaddir . basename($_FILES['file']['name']);
$imagetype  = (pathinfo($uploadfile,PATHINFO_EXTENSION));

if(isset($_POST['submit'])){

    if ($imagetype != 'php7' && $imagetype != 'php' && $imagetype != 'pHp' && $imagetype != 'PHP' && $imagetype != 'pHP' && $imagetype !='Ph' ) {
        move_uploaded_file($_FILES["file"]["tmp_name"], $uploadfile);
        echo "Success";
    }else{
        echo "failed";
    }
}





?>