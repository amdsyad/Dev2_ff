<?php
session_start();
if(!isset($_SESSION['auth'])){
    header("Location: login.php");
}


?>
<!DOCTYPE html>

<html>
    <body style="background-color: powderblue;"></body>
    <center><h2>Welcome To Evil Page!!! :xd</h2></center><br>
</html>
 

<center><h2>Upload Section</h2></center>
<center><img src="img/skull_image2.jpg" alt="" width="200" height="200"></center>
<center><form action="upload.php" method="POST" enctype="multipart/form-data">
    <input type="file" id="file" name="file">
    <input type="submit" name="submit">
</form></center>